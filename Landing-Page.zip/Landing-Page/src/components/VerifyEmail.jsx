import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";

const VerifyEmail = () => {
  const navigate = useNavigate();
  const [verificationCode, setVerificationCode] = useState(["", "", "", ""]);
  const inputRefs = [useRef(), useRef(), useRef(), useRef()];

  const handleChange = (index, value) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newVerificationCode = [...verificationCode];
      newVerificationCode[index] = value;
      setVerificationCode(newVerificationCode);

      if (value !== "" && index < 3) {
        inputRefs[index + 1].current.focus();
      }
    }
  };

  const handleKeyDown = (index, e) => {
    // Move to previous input on backspace if current is empty
    if (e.key === "Backspace" && !verificationCode[index] && index > 0) {
      inputRefs[index - 1].current.focus();
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would verify the code
    navigate("/pet-details");
  };

  const handleResend = () => {
    // Here you would handle resending the code
    alert("Verification code resent!");
  };

  return (
    <div className="phone-container">
      <div className="top-decoration"></div>
      <div className="bottom-decoration"></div>
      <div className="screen">
        <h1>Verify Your Email</h1>
        <h2>
          We have sent a verification code to your email. It expires in 5
          minutes, please check your inbox or spam folder.
        </h2>

        <form onSubmit={handleSubmit}>
          <div className="verification-inputs">
            {verificationCode.map((digit, index) => (
              <input
                key={index}
                ref={inputRefs[index]}
                type="text"
                className="verification-input"
                maxLength="1"
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                required
              />
            ))}
          </div>

          <button type="submit" className="button primary">
            Verify Email
          </button>
        </form>

        <p className="bottom-text">
          Didn't Receive?{" "}
          <a href="#" className="resend-code" onClick={handleResend}>
            Resend Code
          </a>
        </p>

        <div className="login-image">
          <img
            src="https://img.icons8.com/color/240/000000/veterinarian-female.png"
            alt="Pet care illustration"
          />
        </div>
      </div>
    </div>
  );
};

export default VerifyEmail;
