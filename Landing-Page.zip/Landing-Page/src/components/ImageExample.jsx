
import React from 'react';
import { useNavigate } from 'react-router-dom';

const ImageExample = () => {
  const navigate = useNavigate();

  return (
    <div className="phone-container">
      <div className="top-decoration"></div>
      <div className="bottom-decoration"></div>
      <div className="screen">
        <h1>Image Examples</h1>
        <h2>Different ways to use images in React</h2>

        <div className="image-example">
          <h3>Method 1: Import from src/img folder</h3>
          <p>Import images at the top of your component:</p>
          <code>import myImage from '../img/image-name.jpg';</code>
          <p>Then use it in your JSX:</p>
          <code>&lt;img src={myImage} alt="Description" /&gt;</code>
        </div>

        <div className="image-example">
          <h3>Method 2: Using public folder</h3>
          <p>Images in the public folder use absolute paths:</p>
          <code>&lt;img src="/image-name.jpg" alt="Description" /&gt;</code>
        </div>

        <div className="image-example">
          <h3>Method 3: External URLs</h3>
          <p>As you're currently using in components:</p>
          <code>&lt;img src="https://img.icons8.com/..." alt="Description" /&gt;</code>
          <div className="image-container">
            <img 
              src="https://img.icons8.com/color/240/000000/pet-grooming.png" 
              alt="Pet grooming illustration" 
              className="example-image" 
            />
          </div>
        </div>

        <button className="button primary" onClick={() => navigate('/welcome')}>
          Back to Welcome
        </button>
      </div>
    </div>
  );
};

export default ImageExample;
