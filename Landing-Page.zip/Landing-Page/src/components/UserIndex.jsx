import { useState } from "react";

const UsersIndex = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const services = [
    {
      id: 1,
      name: "Basic Grooming",
      description: "A simple bath and cleanliness",
      price: "₱500.00",
    },
    {
      id: 2,
      name: "Standard Grooming",
      description: "A full haircut and styling service",
      price: "₱750.00",
    },
    {
      id: 3,
      name: "Premium Grooming",
      description: "Luxury and extra pampering",
      price: "₱900.00",
    },
  ];

  return (
    <div className="user-page">
      <div className="user-header">
        <div className="user-info">
          <img src="src/img/User.png" alt="Profile" className="profile-pic" />
          <div className="user-text">
            <span className="hello-text">Hello!</span>
            <h1>User</h1>
          </div>
        </div>
      </div>

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search here"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="service-categories">
        <div className="category active">Pet Care</div>
        <div className="category">Pet Supplies</div>
      </div>

      <div className="promo-banner">
        <div className="promo-text">
          <h3>20% First Pet Care Service</h3>
          <p>Enjoy 20% off your pets first grooming or care service!</p>
        </div>
        <button className="promo-button">→</button>
      </div>

      <div className="services-section">
        <h2>Grooming & Hygiene</h2>
        <div className="services-list">
          {services.map((service) => (
            <div key={service.id} className="service-card">
              <div className="service-icon">🐾</div>
              <div className="service-info">
                <h3>{service.name}</h3>
                <p>{service.description}</p>
              </div>
              <div className="service-price">{service.price}</div>
            </div>
          ))}
        </div>
      </div>

      <nav className="bottom-nav">
        <div className="nav-item active">
          <span className="nav-icon">🏠</span>
          <span>Home</span>
        </div>
        <div className="nav-item">
          <span className="nav-icon">🔍</span>
          <span>Explore</span>
        </div>
        <div className="nav-item">
          <span className="nav-icon">📅</span>
          <span>Activity</span>
        </div>
        <div className="nav-item">
          <span className="nav-icon">👤</span>
          <span>Profile</span>
        </div>
      </nav>
    </div>
  );
};

export default UsersIndex;
