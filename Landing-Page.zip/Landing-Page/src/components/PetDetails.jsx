
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const PetDetails = () => {
  const navigate = useNavigate();
  const [selectedPets, setSelectedPets] = useState({
    dog: false,
    cat: false
  });

  const togglePet = (pet) => {
    setSelectedPets({
      ...selectedPets,
      [pet]: !selectedPets[pet]
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    alert('Setup complete! Welcome to FurryFresh!');
     navigate('/user-index');

  };

  return (
    <div className="phone-container">
      <div className="top-decoration"></div>
      <div className="bottom-decoration"></div>
      <div className="screen">
        <h1>Pet Details</h1>
        <h2>Let us know about your pets to personalize their grooming experience!</h2>

        <form onSubmit={handleSubmit}>
          <p>Select all types of pet that you have:</p>
          <div style={{ marginTop: '20px' }}>
            <div 
              className={`pet-option ${selectedPets.dog ? 'selected' : ''}`}
              onClick={() => togglePet('dog')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style={{ marginRight: '5px' }}>
                <path d="M6.825 4.138c.596 2.141-.36 3.593-2.389 4.117a4.432 4.432 0 0 1-2.018.054c-.048-.01.9 2.778 1.522 4.61l.41.016a2.306 2.306 0 0 0 1.318 1.691L6.33 15.525l.773.958c.078.096.179.172.296.225l1.272.545a.63.63 0 0 0 .627-.834l-.918-2.851a.5.5 0 0 1 .165-.535l.927-.926c.623-.627.806-1.509.73-2.752l-.262-2.355a4.5 4.5 0 0 0-.836-2.118l-.102-.1c-1.1-1.077-2.2-1.025-3.11-.228Z"/>
                <path d="M12.129 2.926c.273 1.273-.312 2.322-1.08 3.164-.344.376-.75.683-1.205.94C8.704 7.7 8.56 8.055 9.001 8.55l.002.001a.5.5 0 1 0 .75-.661l-.002-.002c-.273-.307-.02-.389.505-.692a5 5 0 0 0 1.3-1.033c.639-.694.995-1.388.935-2.088-.05-.58-.293-1.064-.645-1.42a.5.5 0 1 0-.707.708c.21.209.37.521.403.892.02.218.001.446-.03.655Z"/>
                <path d="M12.699 9.291c.217.323.374.654.466.98l1.153 4.13A1.5 1.5 0 0 1 13.019 16H11.2a1.5 1.5 0 0 1-1.315-.782l-.422-.842a.5.5 0 1 0-.895.448l.422.842a2.5 2.5 0 0 0 2.19 1.306l1.818.002a2.5 2.5 0 0 0 2.39-3.148l-1.153-4.131c-.106-.38-.297-.775-.55-1.149-.169-.25-.461-.34-.717-.17a.51.51 0 0 0-.17.717Z"/>
              </svg>
              Dog
            </div>
            <div 
              className={`pet-option cat-option ${selectedPets.cat ? 'selected' : ''}`}
              onClick={() => togglePet('cat')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style={{ marginRight: '5px' }}>
                <path d="M8 0a1 1 0 0 1 1 1v5h7a1 1 0 0 1 1 1 6 6 0 0 1-2.658 4.973c.089.52.158.1.221.147h.098a1.5 1.5 0 0 1 1.5 1.499V14.5a1.5 1.5 0 0 1-1.5 1.5H1.5a1.5 1.5 0 0 1-1.5-1.5v-.775a1.5 1.5 0 0 1 1.292-1.488c.111-.097.224-.193.339-.288A6 6 0 0 1 0 7a1 1 0 0 1 1-1h7V1a1 1 0 0 1 1-1Zm7.5 11.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1Z"/>
              </svg>
              Cat
            </div>
          </div>

          <button type="submit" className="button primary">Finish Setup</button>
        </form>

        <div className="login-image">
          <img src="https://img.icons8.com/color/240/000000/veterinarian-female.png" alt="Pet care illustration" />
        </div>
      </div>
    </div>
  );
};

export default PetDetails;
