import { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";
import SplashScreen from "./components/SplashScreen";
import Welcome from "./components/Welcome";
import SignIn from "./components/SignIn";
import SignUp from "./components/SignUp";
import VerifyEmail from "./components/VerifyEmail";
import PetDetails from "./components/PetDetails";
import ImageExample from "./components/ImageExample";
import UsersIndex from "./components/UserIndex";
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SplashScreen />} />
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/verify-email" element={<VerifyEmail />} />
        <Route path="/pet-details" element={<PetDetails />} />
        <Route path="/image-example" element={<ImageExample />} />
        <Route path="/image-example" element={<ImageExample />} />
        <Route path="/user-index" element={<UsersIndex />} />
      </Routes>
    </BrowserRouter>
  );
}
